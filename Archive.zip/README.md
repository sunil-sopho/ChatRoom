# README #

# ChatRoom

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* ChatRoom Project
* Version 0.0.3

### How do I get set up? ###

* enter npm install
* npm start

### Contribution guidelines ###

* Writing make a branch don't directly push to master without consult
* Code review
* allways pull before push to tackle conflict
* Other guidelines

# CONTRIBUTING #
* Anyone With proper knowledge and will to contibute can contribute to the project.
* Fork the repository to make local changes the merge it back.

### Who do I talk to? ###

* Sunil Kumar(Maintainer)
* Other community or team contact